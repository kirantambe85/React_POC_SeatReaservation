
import React, { Component } from 'react';
import {
  BrowserRouter as Router,
  Route,
  Link,
  Switch
} from 'react-router-dom';
import post from './post.json'
import './App.css';
import Login from './components/Login';
import Timer from './components/Timer';
import DatePicker from "react-datepicker";

import "react-datepicker/dist/react-datepicker.css";


window.date = new Date()

class App extends Component {

  constructor(props) {
      super(props);
      this.seatCount = 0
  
      this.state = {
  
        startDate: new Date()
  
      };
  
      this.handleChange = this.handleChange.bind(this);
    this.state = {
      currentDate: null,
      seat: [
        'Desk-1', 'Desk-2', 'Desk-3',
        'Desk-4', 'Desk-5', 'Desk-6',
        'Desk-7', 'Desk-8', 'Desk-9'
      ],
      seatId: ['01', '02', '03', '04', '05', '06', '07', '08', '09'],
      seatAvailable: [
        'Desk-1', 'Desk-2', 'Desk-3',
        'Desk-4', 'Desk-5', 'Desk-6',
        'Desk-7', 'Desk-8', 'Desk-9'
      ],
      seatReserved: [],
      seatSelected: post
    }
    // this.handleClick = this.handleClick.bind(this);
  }

  // onClickData(seat) {
  //   if(this.state.seatReserved.indexOf(seat) > -1 ) {
  //     this.setState({
  //       seatAvailable: this.state.seatAvailable.concat(seat),
  //       seatReserved: this.state.seatReserved.filter(res => res != seat)
  //     })
  //   } else {
  //     this.setState({
  //       seatReserved: this.state.seatReserved.concat(seat),
  //       seatAvailable: this.state.seatAvailable.filter(res => res != seat)
  //     })
  //   }
  // }


  onClickData(seat) {
    <Timer/>
    if (this.state.seatReserved.indexOf(seat) > -1) {
      this.setState({
        seatAvailable: this.state.seatAvailable.concat(seat),
        seatReserved: this.state.seatReserved.filter(res => res != seat),
    })
  setInterval(()=>{
    this.setState({
      seatAvailable: this.state.seatAvailable.concat(seat),
      seatReserved: this.state.seatReserved.filter(res => res != seat),
  })
        //seatSelected: this.state.seatSelected.filter(res => res != seat)
      },10000);
    } else {
      
      
        this.setState({ 
          seatReserved: this.state.seatReserved.concat(seat),
          
          //seatSelected: this.state.seatSelected.concat(seat),
          seatAvailable: this.state.seatAvailable.filter(res => res != seat)
        });
        setInterval(()=>{
          this.setState({
            seatAvailable: this.state.seatAvailable.concat(seat),
            seatReserved: this.state.seatReserved.filter(res => res != seat),
        })
        },10000)
      
       
      
     
    }
  }

  handleChange(date) {
    window.date = date
   this.setState({
   startDate: date
  })
  
  let selectedDiv = document.querySelectorAll(".selected");
  console.log(this.state.seatAvailable)
  console.log(this.state.seatReserved)
  this.state.seatReserved = []
  let makeDivAvailable = document.querySelectorAll(".available")
  
   console.log(makeDivAvailable)
   for (let i = 0; i < makeDivAvailable.length; i++) {
   makeDivAvailable[i].style.pointerEvents= "";
   makeDivAvailable[i].style.cursor= "";
   makeDivAvailable[i].style.opacity="";
  console.log(makeDivAvailable[i])
   }
}
  
  

  checktrue(row) {
    if (this.state.seatSelected.indexOf(row) > -1) {
      return false;
    } else {
      return true;
    }
  }

  handleSubmited() {

    this.setState({
      seatSelected: this.state.seatSelected.concat(this.state.seatReserved),

    });
    this.setState({
      seatReserved: []
    });
    this.setState({
      seconds: this.state.seconds.concat(this.state.seconds),
    })
  }



  // clickMe = () => {
  //   alert(`hello, ${this.state.value}`);
  // }
  // handleClick (){
  //   alert("HI BOI");
  // }

  render() {

    return (
      <div >
        <div>

          <DatePicker

            selected={this.state.startDate}
            selectsStart={this.state.startDate}
            onChange={this.handleChange}
            startDate={new Date()}
            endDate={new Date()}
            minDate={new Date()}
            maxDate={new Date(Date.now() + 4 * 24 * 60 * 60 * 1000)}
            className="dateSel"

          />

        </div>
        <h1>Seat Reservation System</h1>
        <DrawGrid

          seatId={this.state.seatId}
          seat={this.state.seat}
          available={this.state.seatAvailable}
          reserved={this.state.seatReserved}
          onClickData={this.onClickData.bind(this)}
          seconds={this.state.seconds}
          selected={this.state.seatSelected}
          checktrue={this.checktrue.bind(this)}
          handleSubmited={this.handleSubmited.bind(this)}
        />
      </div>
    )
  }
}

class DrawGrid extends React.Component {

  constructor(props) {
    super(props);
    this.state = { seconds: 0 }
    this.seatCount = 0;
    var time = false;
  }


  

  onClickSeat(seat) {

    this.seatCount += 1

    const dateElement = document.querySelector(".dateSel")

    const selectedDate = dateElement.value

    if (window.date != selectedDate && selectedDate != null && window.date != null) {

      this.seatCount = 0

      window.date = null

    }

    if (this.seatCount < 3) {

      this.props.onClickData(seat);

      if (this.seatCount == 3) {

        let list = document.querySelectorAll(".reserve");

        for (let i = 0; i < list.length; i++) {

          list[i].style.pointerEvents = "none";

          list[i].style.cursor = "default";

          list[i].style.opacity = 0.6;

        }

      }

    }

  }

  // componentWillUnmount() {

  //   clearInterval(this.interval);

  // }
  render() {
    return (
      <div className="container">
        <h2></h2>
        <table className="grid">
          <tbody>
            <tr>

              {this.props.seat.map(row =>
                <td
                  className={this.props.reserved.indexOf(row) > -1 ? 'reserved' : 'available'}

                  key={row} onClick={e => this.onClickSeat(row)}>{row} {this.seatCount < 3 ? <Timer  /> : null}</td>)}
                  
            </tr>
          </tbody>
        </table>

        <AvailableList available={this.props.available} />
        <ReservedList reserved={this.props.reserved} />
      </div>
    )
  }



}

class AvailableList extends React.Component {
  render() {
    const seatCount = this.props.available.length;
    return (
      <div className="left">
        <h4>Available Seats: ({seatCount == 0 ? 'No seats available' : seatCount})</h4>
        <ul>
          {this.props.available.map((res) => <li key={res} >{res} </li>)}
        </ul>
      </div>
    )
  }
}

class ReservedList extends React.Component {
  render() {
    return (
      <div className="right">
        <h4>Reserved Seats: ({this.props.reserved.length})</h4>
        <ul>
          {this.props.reserved.map((res, sec) => <li key={res} >{res}</li>)}

        </ul>
      </div>
    )
  }
}



export default App;
